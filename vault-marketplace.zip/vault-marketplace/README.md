# Vault — Digital Asset Marketplace

A full-stack marketplace for buying and selling digital assets. Built with Next.js, Supabase, and Stripe.

---

## Stack

| Layer     | Service         | What it does                         |
|-----------|-----------------|--------------------------------------|
| Frontend  | Next.js + React | UI, routing, server-side API routes  |
| Database  | Supabase        | Products, purchases, user auth       |
| Storage   | Supabase Storage| Secure file hosting                  |
| Payments  | Stripe          | Checkout, webhooks, payouts          |
| Email     | Resend          | Purchase confirmations + download links |
| Hosting   | Vercel          | Deploy in one click                  |

---

## Quickstart

### Step 1 — Clone and install

```bash
git clone https://github.com/yourusername/vault-marketplace.git
cd vault-marketplace
npm install
```

### Step 2 — Set up Supabase

1. Create a project at [supabase.com](https://supabase.com)
2. Go to **SQL Editor** → paste and run `supabase-schema.sql`
3. Go to **Storage** → create a private bucket named `assets`
4. Copy your credentials from **Settings → API**

### Step 3 — Set up Stripe

1. Create an account at [stripe.com](https://stripe.com)
2. Copy your **Publishable Key** and **Secret Key** from the Dashboard
3. Set up a webhook:
   - Go to **Developers → Webhooks → Add endpoint**
   - URL: `https://yourdomain.com/api/webhook`
   - Events: `checkout.session.completed`
   - Copy the **Signing Secret**

### Step 4 — Set up Resend (email)

1. Create an account at [resend.com](https://resend.com)
2. Add and verify your sending domain
3. Create an API key

### Step 5 — Configure environment variables

```bash
cp .env.example .env.local
# Fill in all values in .env.local
```

### Step 6 — Run locally

```bash
npm run dev
# Open http://localhost:3000

# In a separate terminal, forward Stripe webhooks locally:
stripe listen --forward-to localhost:3000/api/webhook
```

### Step 7 — Deploy to Vercel

```bash
# Push to GitHub, then:
# 1. Go to vercel.com → Import your repo
# 2. Add all environment variables from .env.local
# 3. Deploy — takes about 90 seconds
```

After deploying, update your Stripe webhook URL to your live domain.

---

## File structure

```
vault-marketplace/
├── lib/
│   ├── supabase.js          # Supabase browser + admin clients
│   └── resend.js            # Email helper
├── pages/
│   ├── _app.js              # Global CSS loader
│   ├── index.js             # Marketplace UI (main page)
│   ├── success.js           # Post-purchase confirmation
│   └── api/
│       ├── checkout.js      # Creates Stripe session
│       ├── webhook.js       # Handles Stripe events → records purchases
│       └── download.js      # Generates signed download URLs
├── styles/
│   └── globals.css          # CSS variables, resets, animations
├── supabase-schema.sql      # Run once in Supabase SQL Editor
├── .env.example             # Environment variable template
└── package.json
```

---

## How payments work

1. User clicks **Pay $X** → `POST /api/checkout` is called
2. Server fetches product from Supabase, creates a Stripe Checkout session
3. User is redirected to Stripe's hosted payment page
4. On success, Stripe redirects to `/success`
5. Stripe fires a webhook to `/api/webhook`
6. Webhook records the purchase in Supabase and emails the download link
7. User can also download any time via **My Library → Download**

---

## How to upload asset files

**Option A — External URL** (simplest): Host files on Google Drive, Dropbox, or any CDN. Paste the direct download URL when publishing an asset.

**Option B — Supabase Storage** (recommended for security): 
1. Upload `.zip` files to your `assets` bucket
2. Use the storage path (e.g. `product-files/my-asset.zip`) as the download URL
3. The `/api/download` route will automatically generate a signed URL that expires in 1 hour

---

## Customisation

- **Platform fee / Stripe Connect**: To add seller payouts, see [Stripe Connect docs](https://stripe.com/docs/connect)
- **Categories**: Edit the `CATS` array in `pages/index.js`
- **Branding**: Update the logo SVG and color variables in `styles/globals.css`
- **Email template**: Edit `lib/resend.js`

---

## Environment variables reference

| Variable | Where to get it |
|----------|----------------|
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase → Settings → API |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase → Settings → API |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase → Settings → API |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | Stripe → Developers → API keys |
| `STRIPE_SECRET_KEY` | Stripe → Developers → API keys |
| `STRIPE_WEBHOOK_SECRET` | Stripe → Developers → Webhooks |
| `RESEND_API_KEY` | Resend → API Keys |
| `RESEND_FROM_EMAIL` | Your verified sending address |
| `NEXT_PUBLIC_SITE_URL` | Your production URL, e.g. `https://vault.yourdomain.com` |
