import { useState, useEffect, useCallback } from 'react';
import Head from 'next/head';
import { supabase } from '../lib/supabase';

// ─── Constants ───────────────────────────────────────────────
const CATS = ['All', 'Templates', 'UI Kits', 'Scripts', 'Plugins', 'Datasets', 'Fonts'];
const CAT_COLORS = {
  Templates: '#818CF8', 'UI Kits': '#A78BFA', Scripts: '#34D399',
  Plugins: '#60A5FA', Datasets: '#FBBF24', Fonts: '#F472B6',
};

// ─── Shared style objects ─────────────────────────────────────
const inputSx = {
  width: '100%', display: 'block', background: '#07090F',
  border: '1px solid #1A1F2E', borderRadius: 7,
  padding: '9px 12px', fontSize: 13, color: '#EDF0FF', outline: 'none',
};
const labelSx = {
  display: 'block', fontSize: 10, fontWeight: 700, color: '#6B7498',
  textTransform: 'uppercase', letterSpacing: '.07em', marginBottom: 5,
};

const fmtCard = v => v.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();
const fmtExp  = v => { const d = v.replace(/\D/g, '').slice(0, 4); return d.length > 2 ? d.slice(0, 2) + '/' + d.slice(2) : d; };

// ─── Tiny UI helpers ──────────────────────────────────────────
function Field({ label, value, onChange, multiline, rows = 4, ...rest }) {
  const El = multiline ? 'textarea' : 'input';
  return (
    <div style={{ marginBottom: 13 }}>
      {label && <label style={labelSx}>{label}</label>}
      <El
        value={value}
        onChange={e => onChange(e.target.value)}
        style={{ ...inputSx, ...(multiline ? { resize: 'vertical', lineHeight: 1.6 } : {}) }}
        rows={multiline ? rows : undefined}
        {...rest}
      />
    </div>
  );
}

function PrimaryBtn({ children, loading, type = 'button', onClick, color = '#5C6BF5', style: sx }) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={loading}
      style={{
        width: '100%', background: color, color: '#fff',
        border: 'none', borderRadius: 9, padding: '11px',
        fontSize: 14, fontWeight: 700,
        cursor: loading ? 'wait' : 'pointer',
        opacity: loading ? 0.6 : 1, ...sx,
      }}
    >
      {children}
    </button>
  );
}

function Modal({ title, onClose, children, maxW = 420 }) {
  useEffect(() => {
    const esc = e => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', esc);
    return () => window.removeEventListener('keydown', esc);
  }, [onClose]);

  return (
    <div
      onClick={e => e.target === e.currentTarget && onClose()}
      style={{
        position: 'fixed', inset: 0, background: 'rgba(0,0,0,.78)',
        backdropFilter: 'blur(8px)', display: 'flex',
        alignItems: 'center', justifyContent: 'center',
        zIndex: 1000, padding: 20,
      }}
    >
      <div style={{
        background: '#0D1018', border: '1px solid #1A1F2E',
        borderRadius: 16, padding: '24px 26px',
        width: '100%', maxWidth: maxW,
        boxShadow: '0 40px 100px rgba(0,0,0,.75)',
        maxHeight: '90vh', overflowY: 'auto',
        animation: 'fadeIn .2s ease',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <h2 style={{ fontSize: 17, fontWeight: 700, color: '#EDF0FF' }}>{title}</h2>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#6B7498', fontSize: 22, cursor: 'pointer', padding: 0, lineHeight: 1 }}>×</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Toast({ msg, type }) {
  return (
    <div style={{
      position: 'fixed', bottom: 24, right: 24, zIndex: 9999,
      background: type === 'error' ? '#1A0808' : '#071510',
      border: `1px solid ${type === 'error' ? '#F87171' : '#34D399'}`,
      color: type === 'error' ? '#F87171' : '#34D399',
      padding: '10px 15px', borderRadius: 10, fontSize: 13, fontWeight: 500,
      maxWidth: 320, boxShadow: '0 12px 40px rgba(0,0,0,.6)',
      animation: 'toastIn .2s ease',
    }}>
      {msg}
    </div>
  );
}

// ─── Header ──────────────────────────────────────────────────
function Header({ user, search, onSearch, onLogin, onLogout, onPublish, view, setView, purchaseCount, listingCount }) {
  const [menuOpen, setMenuOpen] = useState(false);

  const tabs = [
    { id: 'browse',   label: 'Marketplace' },
    { id: 'library',  label: `My Library${purchaseCount ? ` (${purchaseCount})` : ''}` },
    { id: 'listings', label: `My Listings${listingCount ? ` (${listingCount})` : ''}` },
  ];

  return (
    <header style={{ borderBottom: '1px solid #1A1F2E', background: 'rgba(7,9,15,.97)', position: 'sticky', top: 0, zIndex: 500, padding: '0 24px' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', display: 'flex', alignItems: 'center', height: 60, gap: 10 }}>

        {/* Logo */}
        <div onClick={() => setView('browse')} style={{ display: 'flex', alignItems: 'center', gap: 9, flexShrink: 0, cursor: 'pointer' }}>
          <div style={{ width: 30, height: 30, borderRadius: 7, background: 'linear-gradient(135deg,#5C6BF5 0%,#9B8FF5 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="13" height="13" viewBox="0 0 16 16" fill="none">
              <path d="M8 1L15 4.5V11.5L8 15L1 11.5V4.5Z" stroke="white" strokeWidth="1.5" strokeLinejoin="round"/>
              <circle cx="8" cy="8" r="2.2" fill="white"/>
            </svg>
          </div>
          <span style={{ fontWeight: 800, fontSize: 17, letterSpacing: '-.025em', color: '#EDF0FF' }}>Vault</span>
        </div>

        {/* Nav tabs (logged in only) */}
        {user && (
          <div style={{ display: 'flex', gap: 2, background: '#07090F', border: '1px solid #1A1F2E', borderRadius: 8, padding: 3, flexShrink: 0 }}>
            {tabs.map(t => (
              <button key={t.id} onClick={() => setView(t.id)} style={{ padding: '5px 11px', borderRadius: 6, fontSize: 12, fontWeight: 600, border: 'none', cursor: 'pointer', whiteSpace: 'nowrap', background: view === t.id ? '#111520' : 'transparent', color: view === t.id ? '#EDF0FF' : '#6B7498' }}>
                {t.label}
              </button>
            ))}
          </div>
        )}

        {/* Search */}
        <div style={{ flex: 1, maxWidth: 360, position: 'relative', margin: '0 6px' }}>
          <svg style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: '#232840', pointerEvents: 'none' }} width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          <input value={search} onChange={e => { onSearch(e.target.value); setView('browse'); }} placeholder="Search assets…" style={{ ...inputSx, paddingLeft: 30, borderRadius: 8 }} />
        </div>

        <div style={{ display: 'flex', gap: 7, alignItems: 'center', marginLeft: 'auto', flexShrink: 0 }}>
          <button onClick={onPublish} style={{ background: 'rgba(92,107,245,.12)', border: '1px solid rgba(92,107,245,.3)', color: '#5C6BF5', borderRadius: 7, padding: '6px 12px', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>
            + Publish
          </button>

          {user ? (
            <div style={{ position: 'relative' }}>
              <button onClick={() => setMenuOpen(o => !o)} style={{ display: 'flex', alignItems: 'center', gap: 6, background: '#0D1018', border: '1px solid #1A1F2E', borderRadius: 7, padding: '5px 9px', cursor: 'pointer', color: '#EDF0FF', fontSize: 12 }}>
                <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'linear-gradient(135deg,#5C6BF5,#9B8FF5)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 800, color: '#fff' }}>
                  {(user.user_metadata?.name || user.email)[0].toUpperCase()}
                </div>
                <span style={{ maxWidth: 80, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {user.user_metadata?.name || user.email.split('@')[0]}
                </span>
                <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="m6 9 6 6 6-6"/></svg>
              </button>
              {menuOpen && (
                <div style={{ position: 'absolute', right: 0, top: 'calc(100% + 6px)', background: '#0D1018', border: '1px solid #1A1F2E', borderRadius: 10, overflow: 'hidden', minWidth: 190, boxShadow: '0 12px 40px rgba(0,0,0,.6)', zIndex: 600 }}>
                  <div style={{ padding: '11px 15px', borderBottom: '1px solid #1A1F2E' }}>
                    <p style={{ fontSize: 10, color: '#6B7498', marginBottom: 2 }}>Signed in as</p>
                    <p style={{ fontSize: 13, fontWeight: 600, color: '#EDF0FF' }}>{user.email}</p>
                  </div>
                  <button onClick={() => { setView('library'); setMenuOpen(false); }} style={{ display: 'block', width: '100%', padding: '10px 15px', background: 'none', border: 'none', color: '#EDF0FF', fontSize: 13, cursor: 'pointer', textAlign: 'left' }}>📦 My Library</button>
                  <button onClick={() => { setView('listings'); setMenuOpen(false); }} style={{ display: 'block', width: '100%', padding: '10px 15px', background: 'none', border: 'none', color: '#EDF0FF', fontSize: 13, cursor: 'pointer', textAlign: 'left' }}>🗂️ My Listings</button>
                  <div style={{ borderTop: '1px solid #1A1F2E' }} />
                  <button onClick={() => { onLogout(); setMenuOpen(false); }} style={{ display: 'block', width: '100%', padding: '10px 15px', background: 'none', border: 'none', color: '#F87171', fontSize: 13, fontWeight: 500, cursor: 'pointer', textAlign: 'left' }}>Sign Out</button>
                </div>
              )}
            </div>
          ) : (
            <button onClick={onLogin} style={{ background: '#5C6BF5', color: '#fff', border: 'none', borderRadius: 7, padding: '6px 14px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Sign In</button>
          )}
        </div>
      </div>
    </header>
  );
}

// ─── Product Card ─────────────────────────────────────────────
function ProductCard({ product, owned, onBuy, onDetail, idx }) {
  const [hov, setHov] = useState(false);
  const cc = CAT_COLORS[product.category] || '#9CA3AF';
  return (
    <div
      className="card-anim"
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: hov ? '#111520' : '#0D1018',
        border: `1px solid ${hov ? '#2D3550' : '#1A1F2E'}`,
        borderRadius: 14, overflow: 'hidden',
        display: 'flex', flexDirection: 'column',
        transition: 'all .18s ease',
        transform: hov ? 'translateY(-2px)' : 'none',
        boxShadow: hov ? '0 16px 48px rgba(0,0,0,.4)' : 'none',
        animationDelay: `${idx * 0.04}s`,
      }}
    >
      <div style={{ height: 2, background: hov ? `linear-gradient(90deg,transparent,${cc}CC,transparent)` : 'transparent', transition: 'background .3s' }} />
      <div style={{ padding: '19px 19px 13px', flex: 1, display: 'flex', flexDirection: 'column' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 11 }}>
          <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: '.09em', textTransform: 'uppercase', color: cc, background: cc + '1A', padding: '3px 8px', borderRadius: 100 }}>{product.category}</span>
          <span style={{ fontSize: 17, fontWeight: 800, color: '#34D399', letterSpacing: '-.03em' }}>${product.price}</span>
        </div>
        <h3 onClick={() => onDetail(product)} style={{ fontSize: 15, fontWeight: 700, color: '#EDF0FF', marginBottom: 8, lineHeight: 1.35, cursor: 'pointer' }}>{product.title}</h3>
        <p style={{ fontSize: 13, color: '#6B7498', lineHeight: 1.65, flex: 1, marginBottom: 11 }}>{product.description}</p>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          {product.downloads > 0 && <span style={{ fontSize: 11, color: '#232840' }}>↓ {product.downloads.toLocaleString()}</span>}
          {product.rating    && <span style={{ fontSize: 11, color: '#232840' }}>★ {product.rating}</span>}
          {product.author_name && <span style={{ fontSize: 11, color: '#232840', marginLeft: 'auto' }}>by {product.author_name}</span>}
        </div>
      </div>
      <div style={{ padding: '0 19px 19px' }}>
        <button
          onClick={onBuy}
          style={{
            width: '100%', padding: '9px',
            background: owned ? '#059669' : hov ? '#5C6BF5' : 'transparent',
            border: `1px solid ${owned ? '#059669' : hov ? '#5C6BF5' : '#232840'}`,
            color: owned || hov ? '#fff' : '#6B7498',
            borderRadius: 8, fontSize: 13, fontWeight: 600,
            cursor: 'pointer', transition: 'all .18s',
          }}
        >
          {owned ? '✓ View in Library' : hov ? 'Purchase Asset →' : 'Acquire Asset'}
        </button>
      </div>
    </div>
  );
}

// ─── Views ────────────────────────────────────────────────────
function BrowseView({ products, purchases, user, search, category, setCategory, sort, setSort, onBuy, onDetail, setModal }) {
  const purchasedIds = new Set(purchases.map(p => p.product_id));

  let items = products.filter(p => {
    const q = search.toLowerCase();
    return (!q || p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q))
        && (category === 'All' || p.category === category);
  });

  if (sort === 'price_asc')  items = [...items].sort((a, b) => a.price - b.price);
  if (sort === 'price_desc') items = [...items].sort((a, b) => b.price - a.price);
  if (sort === 'rating')     items = [...items].sort((a, b) => (b.rating || 0) - (a.rating || 0));
  if (sort === 'popular')    items = [...items].sort((a, b) => (b.downloads || 0) - (a.downloads || 0));

  return (
    <>
      {/* Category tabs */}
      <div style={{ display: 'flex', gap: 7, flexWrap: 'wrap', marginBottom: 22 }}>
        {CATS.map(c => (
          <button key={c} onClick={() => setCategory(c)} style={{ padding: '6px 13px', borderRadius: 100, fontSize: 10, fontWeight: 700, letterSpacing: '.07em', textTransform: 'uppercase', border: `1px solid ${category === c ? '#5C6BF5' : '#1A1F2E'}`, background: category === c ? 'rgba(92,107,245,.12)' : 'transparent', color: category === c ? '#5C6BF5' : '#6B7498', cursor: 'pointer' }}>
            {c}
          </button>
        ))}
      </div>

      {/* Sort + count bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18, flexWrap: 'wrap', gap: 10 }}>
        <p style={{ color: '#232840', fontSize: 12 }}>
          {items.length} asset{items.length !== 1 ? 's' : ''}
          {category !== 'All' ? ` in ${category}` : ''}
          {search ? ` matching "${search}"` : ''}
          {!user ? <> · <span onClick={() => setModal('auth')} style={{ color: '#5C6BF5', cursor: 'pointer' }}>Sign in to purchase</span></> : null}
        </p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 11, color: '#6B7498' }}>Sort:</span>
          <select value={sort} onChange={e => setSort(e.target.value)} style={{ ...inputSx, width: 'auto', padding: '5px 10px', fontSize: 12, borderRadius: 6 }}>
            <option value="newest">Newest</option>
            <option value="popular">Most Popular</option>
            <option value="rating">Top Rated</option>
            <option value="price_asc">Price: Low → High</option>
            <option value="price_desc">Price: High → Low</option>
          </select>
        </div>
      </div>

      {/* Grid */}
      {items.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '80px 0' }}>
          <p style={{ fontSize: 36, marginBottom: 12 }}>🔍</p>
          <p style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>No assets found</p>
          <p style={{ fontSize: 13, color: '#6B7498' }}>Try adjusting your search or category</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(275px,1fr))', gap: 15 }}>
          {items.map((p, i) => (
            <ProductCard
              key={p.id} product={p} idx={i}
              owned={purchasedIds.has(p.id)}
              onDetail={onDetail}
              onBuy={() => purchasedIds.has(p.id) ? null : onBuy(p)}
            />
          ))}
        </div>
      )}
    </>
  );
}

function LibraryView({ purchases, onDownload, onDetail }) {
  if (!purchases.length) return (
    <div style={{ textAlign: 'center', padding: '80px 0' }}>
      <p style={{ fontSize: 40, marginBottom: 12 }}>📦</p>
      <p style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Your library is empty</p>
      <p style={{ fontSize: 13, color: '#6B7498' }}>Assets you purchase will appear here with download links</p>
    </div>
  );

  return (
    <div>
      <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 20 }}>
        My Library <span style={{ fontSize: 13, color: '#6B7498', fontWeight: 400 }}>({purchases.length} asset{purchases.length !== 1 ? 's' : ''})</span>
      </h2>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {purchases.map(p => {
          const prod = p.products;
          if (!prod) return null;
          const cc = CAT_COLORS[prod.category] || '#9CA3AF';
          return (
            <div key={p.id} style={{ background: '#0D1018', border: '1px solid #1A1F2E', borderRadius: 12, padding: '15px 18px', display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{ width: 44, height: 44, borderRadius: 10, background: cc + '18', border: `1px solid ${cc}30`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontSize: 20 }}>
                {{ Templates: '📄', 'UI Kits': '🎨', Scripts: '⚙️', Plugins: '🔌', Datasets: '📊', Fonts: '🔤' }[prod.category] || '📦'}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontWeight: 700, fontSize: 14, color: '#EDF0FF' }}>{prod.title}</p>
                <p style={{ fontSize: 12, color: '#6B7498', marginTop: 2 }}>
                  {prod.category} · Purchased {new Date(p.created_at).toLocaleDateString()}
                </p>
              </div>
              <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
                <button onClick={() => onDetail(prod)} style={{ background: '#232840', color: '#6B7498', border: 'none', borderRadius: 7, padding: '7px 12px', fontSize: 12, fontWeight: 600, cursor: 'pointer' }}>Details</button>
                <button onClick={() => onDownload(prod.id)} style={{ background: 'rgba(92,107,245,.12)', border: '1px solid rgba(92,107,245,.3)', color: '#5C6BF5', borderRadius: 7, padding: '7px 14px', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>↓ Download</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ListingsView({ listings, onPublish, onRemove }) {
  if (!listings.length) return (
    <div style={{ textAlign: 'center', padding: '80px 0' }}>
      <p style={{ fontSize: 40, marginBottom: 12 }}>🗂️</p>
      <p style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>No listings yet</p>
      <p style={{ fontSize: 13, color: '#6B7498', marginBottom: 20 }}>Publish your first asset and start earning</p>
      <button onClick={onPublish} style={{ background: '#5C6BF5', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 20px', fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Publish an Asset</button>
    </div>
  );

  const totalRevenue = listings.reduce((s, p) => s + (p.price * (p.downloads || 0)), 0);
  const avgRating = listings.filter(p => p.rating).length
    ? (listings.filter(p => p.rating).reduce((s, p) => s + p.rating, 0) / listings.filter(p => p.rating).length).toFixed(1)
    : '—';

  return (
    <div>
      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(150px,1fr))', gap: 12, marginBottom: 28 }}>
        {[
          { label: 'Listings',       val: listings.length,                        c: '#5C6BF5' },
          { label: 'Est. Revenue',   val: `$${totalRevenue.toLocaleString()}`,     c: '#34D399' },
          { label: 'Downloads',      val: listings.reduce((s, p) => s + (p.downloads || 0), 0).toLocaleString(), c: '#60A5FA' },
          { label: 'Avg Rating',     val: avgRating === '—' ? '—' : avgRating + '★', c: '#FBBF24' },
        ].map(s => (
          <div key={s.label} style={{ background: '#0D1018', border: '1px solid #1A1F2E', borderRadius: 10, padding: '14px 16px' }}>
            <p style={{ fontSize: 10, color: '#6B7498', textTransform: 'uppercase', letterSpacing: '.06em', fontWeight: 700, marginBottom: 6 }}>{s.label}</p>
            <p style={{ fontSize: 22, fontWeight: 800, color: s.c }}>{s.val}</p>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <h3 style={{ fontSize: 15, fontWeight: 700 }}>Your Assets</h3>
        <button onClick={onPublish} style={{ background: 'rgba(92,107,245,.12)', border: '1px solid rgba(92,107,245,.3)', color: '#5C6BF5', borderRadius: 7, padding: '7px 14px', fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>+ Publish New</button>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {listings.map(p => {
          const cc = CAT_COLORS[p.category] || '#9CA3AF';
          return (
            <div key={p.id} style={{ background: '#0D1018', border: '1px solid #1A1F2E', borderRadius: 12, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: '.08em', textTransform: 'uppercase', color: cc, background: cc + '1A', padding: '3px 9px', borderRadius: 100, flexShrink: 0 }}>{p.category}</span>
              <p style={{ fontWeight: 700, fontSize: 14, flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.title}</p>
              <div style={{ display: 'flex', gap: 18, alignItems: 'center', flexShrink: 0 }}>
                <span style={{ fontSize: 12, color: '#232840' }}>↓ {(p.downloads || 0).toLocaleString()}</span>
                <span style={{ fontSize: 15, fontWeight: 700, color: '#34D399' }}>${p.price}</span>
                <button onClick={() => onRemove(p.id)} style={{ background: 'rgba(248,113,113,.1)', border: '1px solid rgba(248,113,113,.2)', color: '#F87171', borderRadius: 6, padding: '5px 10px', fontSize: 12, cursor: 'pointer' }}>Remove</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────
export default function Home() {
  const [user, setUser] = useState(null);
  const [products, setProducts]   = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [listings, setListings]   = useState([]);
  const [search,   setSearch]     = useState('');
  const [category, setCategory]   = useState('All');
  const [sort,     setSort]       = useState('newest');
  const [view,     setView]       = useState('browse');
  const [modal,    setModal]      = useState(null);
  const [toast,    setToast]      = useState(null);
  const [loading,  setLoading]    = useState(false);
  const [detailProduct, setDetailProduct] = useState(null);
  const [selProduct,    setSelProduct]    = useState(null);

  // Auth form
  const [aEmail, setAEmail] = useState('');
  const [aPass,  setAPass]  = useState('');
  const [aName,  setAName]  = useState('');
  const [authMode, setAuthMode] = useState('login');

  // Publish form
  const [pTitle, setPTitle]   = useState('');
  const [pDesc,  setPDesc]    = useState('');
  const [pPrice, setPPrice]   = useState('');
  const [pCat,   setPCat]     = useState('Templates');
  const [pUrl,   setPUrl]     = useState('');
  const [pNotes, setPNotes]   = useState('');

  // Checkout form (kept for UI — actual payment via Stripe redirect)
  const [cName, setCName] = useState('');
  const [cNum,  setCNum]  = useState('');
  const [cExp,  setCExp]  = useState('');
  const [cCvv,  setCCvv]  = useState('');

  const showToast = useCallback((msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  }, []);

  // ── Fetch products ───────────────────────────────────────────
  const fetchProducts = useCallback(async () => {
    const { data, error } = await supabase
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error && data) setProducts(data);
  }, []);

  // ── Fetch user's purchases ────────────────────────────────────
  const fetchPurchases = useCallback(async (userId) => {
    const { data } = await supabase
      .from('purchases')
      .select('*, products(*)')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (data) setPurchases(data);
  }, []);

  // ── Fetch user's listings ────────────────────────────────────
  const fetchListings = useCallback(async (userId) => {
    const { data } = await supabase
      .from('products')
      .select('*')
      .eq('author_id', userId)
      .order('created_at', { ascending: false });
    if (data) setListings(data);
  }, []);

  // ── Bootstrap ────────────────────────────────────────────────
  useEffect(() => {
    fetchProducts();

    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        setUser(session.user);
        fetchPurchases(session.user.id);
        fetchListings(session.user.id);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      const u = session?.user ?? null;
      setUser(u);
      if (u) {
        fetchPurchases(u.id);
        fetchListings(u.id);
      } else {
        setPurchases([]);
        setListings([]);
        setView('browse');
      }
    });

    return () => subscription.unsubscribe();
  }, [fetchProducts, fetchPurchases, fetchListings]);

  // ── Auth ─────────────────────────────────────────────────────
  const handleAuth = async (e) => {
    e.preventDefault();
    if (!aEmail || aPass.length < 6) { showToast('Enter a valid email and password (6+ chars)', 'error'); return; }
    setLoading(true);
    let error;
    if (authMode === 'signup') {
      ({ error } = await supabase.auth.signUp({
        email: aEmail, password: aPass,
        options: { data: { name: aName || aEmail.split('@')[0] } },
      }));
      if (!error) showToast('Check your email to confirm your account!');
    } else {
      ({ error } = await supabase.auth.signInWithPassword({ email: aEmail, password: aPass }));
      if (!error) { setModal(null); showToast('Signed in successfully'); }
    }
    if (error) showToast(error.message, 'error');
    setLoading(false);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    showToast('Signed out');
  };

  // ── Publish ──────────────────────────────────────────────────
  const handlePublish = async (e) => {
    e.preventDefault();
    if (!pTitle || !pDesc || !pPrice || !pUrl) { showToast('Please fill in all required fields', 'error'); return; }
    setLoading(true);
    const { data, error } = await supabase.from('products').insert({
      title: pTitle, description: pDesc, category: pCat,
      price: parseFloat(pPrice), download_url: pUrl,
      preview_notes: pNotes, author_id: user.id,
      author_name: user.user_metadata?.name || user.email.split('@')[0],
    }).select().single();

    if (error) { showToast(error.message, 'error'); }
    else {
      setProducts(prev => [data, ...prev]);
      setListings(prev => [data, ...prev]);
      setModal(null);
      setPTitle(''); setPDesc(''); setPPrice(''); setPUrl(''); setPNotes('');
      showToast('Asset published! It\'s now live on the marketplace.');
    }
    setLoading(false);
  };

  // ── Checkout → Stripe ────────────────────────────────────────
  const handleCheckout = async (e) => {
    e.preventDefault();
    if (!cName || cNum.replace(/\s/g,'').length < 16 || !cExp || !cCvv) {
      showToast('Please complete all card details', 'error'); return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ productId: selProduct.id, userId: user.id, userEmail: user.email }),
      });
      const { url, error } = await res.json();
      if (error) throw new Error(error);
      window.location.href = url; // Redirect to Stripe Checkout
    } catch (err) {
      showToast(err.message || 'Checkout failed', 'error');
      setLoading(false);
    }
  };

  // ── Download ─────────────────────────────────────────────────
  const handleDownload = async (productId) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const res = await fetch(`/api/download?productId=${productId}`, {
        headers: { Authorization: `Bearer ${session.access_token}` },
      });
      const { url, error } = await res.json();
      if (error) throw new Error(error);
      window.open(url, '_blank');
    } catch (err) {
      showToast(err.message || 'Download failed', 'error');
    }
  };

  // ── Remove listing ───────────────────────────────────────────
  const handleRemove = async (productId) => {
    if (!confirm('Remove this listing? This cannot be undone.')) return;
    const { error } = await supabase.from('products').delete().eq('id', productId);
    if (error) { showToast(error.message, 'error'); return; }
    setProducts(prev => prev.filter(p => p.id !== productId));
    setListings(prev => prev.filter(p => p.id !== productId));
    showToast('Listing removed');
  };

  // ── Render ───────────────────────────────────────────────────
  const currentView = user && view !== 'browse' ? view : 'browse';

  return (
    <>
      <Head>
        <title>Vault — Digital Asset Marketplace</title>
        <meta name="description" content="Buy and sell premium digital assets: templates, UI kits, scripts, fonts, datasets, and plugins." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Header
        user={user}
        search={search}
        onSearch={setSearch}
        onLogin={() => { setAuthMode('login'); setModal('auth'); }}
        onLogout={handleLogout}
        onPublish={() => user ? setModal('publish') : (setAuthMode('login'), setModal('auth'))}
        view={currentView}
        setView={setView}
        purchaseCount={purchases.length}
        listingCount={listings.length}
      />

      <main style={{ maxWidth: 1280, margin: '0 auto', padding: '28px 24px' }}>
        {currentView === 'browse' && (
          <BrowseView
            products={products}
            purchases={purchases}
            user={user}
            search={search}
            category={category}
            setCategory={setCategory}
            sort={sort}
            setSort={setSort}
            setModal={setModal}
            onBuy={p => {
              if (!user) { setAuthMode('login'); setModal('auth'); return; }
              setSelProduct(p);
              setModal('checkout');
            }}
            onDetail={p => { setDetailProduct(p); setModal('detail'); }}
          />
        )}
        {currentView === 'library' && (
          <LibraryView
            purchases={purchases}
            onDownload={handleDownload}
            onDetail={p => { setDetailProduct(p); setModal('detail'); }}
          />
        )}
        {currentView === 'listings' && (
          <ListingsView
            listings={listings}
            onPublish={() => setModal('publish')}
            onRemove={handleRemove}
          />
        )}
      </main>

      {/* ── Auth Modal ─────────────────────────────────────────── */}
      {modal === 'auth' && (
        <Modal title={authMode === 'signup' ? 'Create Account' : 'Sign In to Vault'} onClose={() => setModal(null)}>
          <form onSubmit={handleAuth}>
            {authMode === 'signup' && <Field label="Name" value={aName} onChange={setAName} placeholder="Your name" />}
            <Field label="Email" type="email" value={aEmail} onChange={setAEmail} placeholder="you@example.com" autoComplete="email" />
            <Field label="Password" type="password" value={aPass} onChange={setAPass} placeholder="••••••••" />
            <PrimaryBtn type="submit" loading={loading}>
              {loading ? 'Processing…' : authMode === 'signup' ? 'Create Account' : 'Sign In'}
            </PrimaryBtn>
          </form>
          <p style={{ textAlign: 'center', marginTop: 14, fontSize: 13, color: '#6B7498' }}>
            {authMode === 'login' ? 'No account? ' : 'Already a member? '}
            <span onClick={() => setAuthMode(m => m === 'login' ? 'signup' : 'login')} style={{ color: '#5C6BF5', cursor: 'pointer', fontWeight: 700 }}>
              {authMode === 'login' ? 'Sign up free' : 'Sign in'}
            </span>
          </p>
        </Modal>
      )}

      {/* ── Publish Modal ──────────────────────────────────────── */}
      {modal === 'publish' && (
        <Modal title="Publish an Asset" onClose={() => setModal(null)} maxW={520}>
          <form onSubmit={handlePublish}>
            <Field label="Title *" value={pTitle} onChange={setPTitle} placeholder="e.g. Next.js SaaS Starter Kit" />
            <div style={{ marginBottom: 13 }}>
              <label style={labelSx}>Category *</label>
              <select value={pCat} onChange={e => setPCat(e.target.value)} style={{ ...inputSx, appearance: 'none' }}>
                {CATS.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <Field label="Price ($) *" type="number" min="0" step="0.01" value={pPrice} onChange={setPPrice} placeholder="29" />
              <Field label="Download URL *" value={pUrl} onChange={setPUrl} placeholder="https://…" />
            </div>
            <Field label="Description *" value={pDesc} onChange={setPDesc} multiline placeholder="What's included, who it's for, and what makes it valuable…" />
            <Field label="What's Included (optional)" value={pNotes} onChange={setPNotes} multiline rows={3} placeholder="List the specific files, components, pages, etc." />
            <PrimaryBtn type="submit" loading={loading}>
              {loading ? 'Publishing…' : 'Publish to Marketplace'}
            </PrimaryBtn>
          </form>
        </Modal>
      )}

      {/* ── Detail Modal ───────────────────────────────────────── */}
      {modal === 'detail' && detailProduct && (() => {
        const p = detailProduct;
        const cc = CAT_COLORS[p.category] || '#9CA3AF';
        const owned = purchases.some(x => x.product_id === p.id);
        return (
          <Modal title={p.title} onClose={() => setModal(null)} maxW={480}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <span style={{ fontSize: 9, fontWeight: 800, letterSpacing: '.09em', textTransform: 'uppercase', color: cc, background: cc + '1A', padding: '3px 9px', borderRadius: 100 }}>{p.category}</span>
              <span style={{ fontSize: 22, fontWeight: 800, color: '#34D399' }}>${p.price}</span>
            </div>
            <p style={{ fontSize: 14, color: '#6B7498', lineHeight: 1.7, marginBottom: 16 }}>{p.description}</p>
            {p.preview_notes && (
              <div style={{ background: '#07090F', border: '1px solid #1A1F2E', borderRadius: 9, padding: 14, marginBottom: 16 }}>
                <p style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.07em', color: '#6B7498', marginBottom: 8 }}>What's included</p>
                <p style={{ fontSize: 13, color: '#EDF0FF', lineHeight: 1.7 }}>{p.preview_notes}</p>
              </div>
            )}
            <div style={{ display: 'flex', gap: 20, marginBottom: 20 }}>
              {p.downloads > 0 && <div><p style={{ fontSize: 16, fontWeight: 800 }}>{p.downloads.toLocaleString()}</p><p style={{ fontSize: 10, color: '#6B7498', textTransform: 'uppercase', letterSpacing: '.06em' }}>Downloads</p></div>}
              {p.rating     && <div><p style={{ fontSize: 16, fontWeight: 800 }}>{p.rating} ★</p><p style={{ fontSize: 10, color: '#6B7498', textTransform: 'uppercase', letterSpacing: '.06em' }}>Rating</p></div>}
              {p.author_name && <div style={{ marginLeft: 'auto' }}><p style={{ fontSize: 14, fontWeight: 700 }}>{p.author_name}</p><p style={{ fontSize: 10, color: '#6B7498', textTransform: 'uppercase', letterSpacing: '.06em' }}>Creator</p></div>}
            </div>
            {owned
              ? <PrimaryBtn color="#059669" onClick={() => { setModal(null); setView('library'); }}>✓ View in Library</PrimaryBtn>
              : <PrimaryBtn onClick={() => { user ? (setSelProduct(p), setModal('checkout')) : (setAuthMode('login'), setModal('auth')); }}>Purchase · ${p.price}</PrimaryBtn>
            }
          </Modal>
        );
      })()}

      {/* ── Checkout Modal ─────────────────────────────────────── */}
      {modal === 'checkout' && selProduct && (
        <Modal title="Complete Your Purchase" onClose={() => setModal(null)}>
          <div style={{ background: '#07090F', border: '1px solid #1A1F2E', borderRadius: 10, padding: '13px 15px', marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <p style={{ fontWeight: 700, fontSize: 14, color: '#EDF0FF' }}>{selProduct.title}</p>
                <p style={{ fontSize: 12, color: '#6B7498', marginTop: 2 }}>{selProduct.category}</p>
              </div>
              <p style={{ fontSize: 22, fontWeight: 800, color: '#34D399' }}>${selProduct.price}</p>
            </div>
          </div>
          <form onSubmit={handleCheckout}>
            <Field label="Cardholder Name" value={cName} onChange={setCName} placeholder="Jane Smith" />
            <Field label="Card Number" value={cNum} onChange={v => setCNum(fmtCard(v))} placeholder="4242 4242 4242 4242" maxLength={19} />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <Field label="Expiry" value={cExp} onChange={v => setCExp(fmtExp(v))} placeholder="MM/YY" maxLength={5} />
              <Field label="CVV" value={cCvv} onChange={v => setCCvv(v.replace(/\D/g,'').slice(0,3))} placeholder="123" maxLength={3} />
            </div>
            <PrimaryBtn type="submit" loading={loading} color="#059669">
              {loading ? 'Redirecting to Stripe…' : `Pay $${selProduct.price} →`}
            </PrimaryBtn>
          </form>
          <p style={{ textAlign: 'center', fontSize: 11, color: '#232840', marginTop: 10 }}>🔒 Secured by Stripe — your card details are never stored on our servers</p>
        </Modal>
      )}

      {/* ── Toast ─────────────────────────────────────────────── */}
      {toast && <Toast msg={toast.msg} type={toast.type} />}
    </>
  );
}
