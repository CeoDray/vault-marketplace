import { getSupabaseAdmin } from '../../lib/supabase';
import { createClient } from '@supabase/supabase-js';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });

  const { productId } = req.query;
  if (!productId) return res.status(400).json({ error: 'Missing productId' });

  // ── Verify the user's session token ─────────────────────────
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  const token = authHeader.slice(7);

  // Validate token against Supabase
  const supabaseClient = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  );
  const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);
  if (authError || !user) return res.status(401).json({ error: 'Invalid session' });

  const supabaseAdmin = getSupabaseAdmin();

  // ── Verify the user has purchased this product ───────────────
  const { data: purchase, error: purchaseError } = await supabaseAdmin
    .from('purchases')
    .select('id')
    .eq('user_id', user.id)
    .eq('product_id', productId)
    .single();

  if (purchaseError || !purchase) {
    return res.status(403).json({ error: 'You have not purchased this asset' });
  }

  // ── Fetch the product's download URL ─────────────────────────
  const { data: product, error: productError } = await supabaseAdmin
    .from('products')
    .select('download_url, title')
    .eq('id', productId)
    .single();

  if (productError || !product) {
    return res.status(404).json({ error: 'Product not found' });
  }

  let downloadUrl = product.download_url;

  // If the download_url is a Storage path (not a full URL), generate a signed URL
  if (downloadUrl && !downloadUrl.startsWith('http')) {
    const { data, error: storageError } = await supabaseAdmin.storage
      .from('assets')
      .createSignedUrl(downloadUrl, 60 * 60); // 1-hour signed URL

    if (storageError || !data?.signedUrl) {
      return res.status(500).json({ error: 'Failed to generate download link' });
    }
    downloadUrl = data.signedUrl;
  }

  return res.status(200).json({ url: downloadUrl });
}
