import Stripe from 'stripe';
import { buffer } from 'micro';
import { getSupabaseAdmin } from '../../lib/supabase';
import { sendPurchaseConfirmation } from '../../lib/resend';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// ⚠️ Disable Next.js body parsing — Stripe needs the raw body to verify signature
export const config = {
  api: { bodyParser: false },
};

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end('Method Not Allowed');

  const sig = req.headers['stripe-signature'];
  let event;

  try {
    const rawBody = await buffer(req);
    event = stripe.webhooks.constructEvent(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // ── Handle payment confirmed ─────────────────────────────────
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const { product_id, user_id, user_email } = session.metadata;

    if (!product_id || !user_id) {
      console.error('Missing metadata in Stripe session:', session.id);
      return res.status(200).json({ received: true }); // Acknowledge to avoid retries
    }

    const supabaseAdmin = getSupabaseAdmin();

    // 1. Record the purchase in Supabase
    const { error: purchaseError } = await supabaseAdmin
      .from('purchases')
      .upsert({
        user_id,
        product_id,
        stripe_session_id: session.id,
        amount_paid: session.amount_total / 100,
      }, { onConflict: 'stripe_session_id' });

    if (purchaseError) {
      console.error('Failed to record purchase:', purchaseError);
    }

    // 2. Increment download counter
    await supabaseAdmin.rpc('increment_downloads', { product_id });

    // 3. Generate a time-limited download URL and email it
    try {
      const { data: product } = await supabaseAdmin
        .from('products')
        .select('title, download_url')
        .eq('id', product_id)
        .single();

      let downloadUrl = product?.download_url;

      // If the URL is a Supabase Storage path (not a full URL), generate a signed URL
      if (downloadUrl && !downloadUrl.startsWith('http')) {
        const { data } = await supabaseAdmin.storage
          .from('assets')
          .createSignedUrl(downloadUrl, 60 * 60 * 24); // 24-hour link
        downloadUrl = data?.signedUrl;
      }

      if (downloadUrl && user_email && product) {
        await sendPurchaseConfirmation({
          toEmail: user_email,
          productTitle: product.title,
          downloadUrl,
        });
      }
    } catch (emailErr) {
      // Don't fail the webhook if email fails — purchase is still recorded
      console.error('Email delivery failed:', emailErr);
    }
  }

  return res.status(200).json({ received: true });
}
