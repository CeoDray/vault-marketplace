import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import Link from 'next/link';

export default function Success() {
  const router = useRouter();
  const { session_id } = router.query;
  const [status, setStatus] = useState('loading'); // loading | confirmed | error

  useEffect(() => {
    if (!session_id) return;
    // Optionally verify the session server-side here
    // For now, showing confirmation optimistically (webhook handles DB write)
    setStatus('confirmed');
  }, [session_id]);

  return (
    <>
      <Head>
        <title>Purchase Confirmed — Vault</title>
      </Head>
      <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, background: '#07090F' }}>
        <div style={{ textAlign: 'center', maxWidth: 480 }}>
          {status === 'loading' && (
            <p style={{ color: '#6B7498', fontSize: 15 }}>Confirming your purchase…</p>
          )}
          {status === 'confirmed' && (
            <>
              <div style={{ width: 72, height: 72, borderRadius: '50%', background: 'rgba(52,211,153,.12)', border: '1px solid rgba(52,211,153,.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 24px', fontSize: 32 }}>
                ✓
              </div>
              <h1 style={{ fontSize: 26, fontWeight: 800, color: '#EDF0FF', marginBottom: 12 }}>Purchase Confirmed!</h1>
              <p style={{ fontSize: 15, color: '#6B7498', lineHeight: 1.7, marginBottom: 8 }}>
                Your asset is ready. We've sent a download link to your email — check your inbox.
              </p>
              <p style={{ fontSize: 13, color: '#232840', marginBottom: 32 }}>
                You can also access it any time in your library.
              </p>
              <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
                <Link href="/?view=library" style={{ background: '#5C6BF5', color: '#fff', textDecoration: 'none', borderRadius: 9, padding: '11px 24px', fontWeight: 700, fontSize: 14 }}>
                  Go to My Library
                </Link>
                <Link href="/" style={{ background: '#0D1018', color: '#6B7498', textDecoration: 'none', borderRadius: 9, padding: '11px 24px', fontWeight: 600, fontSize: 14, border: '1px solid #1A1F2E' }}>
                  Keep Browsing
                </Link>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}
