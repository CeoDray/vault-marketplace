-- ============================================================
-- VAULT MARKETPLACE — Supabase Schema
-- Run this in: supabase.com → SQL Editor → New Query
-- ============================================================

-- Products table
create table if not exists public.products (
  id          uuid default gen_random_uuid() primary key,
  title       text not null,
  description text not null,
  category    text not null,
  price       numeric(10,2) not null check (price >= 0),
  download_url text not null,          -- stored in Supabase Storage or external URL
  preview_notes text,                  -- "What's included" text
  author_id   uuid references auth.users on delete cascade,
  author_name text,
  downloads   integer default 0,
  rating      numeric(3,1),
  created_at  timestamptz default now()
);

-- Purchases table
create table if not exists public.purchases (
  id                  uuid default gen_random_uuid() primary key,
  user_id             uuid references auth.users on delete cascade not null,
  product_id          uuid references public.products on delete cascade not null,
  stripe_session_id   text unique,
  amount_paid         numeric(10,2),
  created_at          timestamptz default now(),
  unique(user_id, product_id)   -- prevent duplicate purchases
);

-- ─── Row Level Security ─────────────────────────────────────
alter table public.products  enable row level security;
alter table public.purchases enable row level security;

-- Products: anyone can read; only the author can insert/update/delete
create policy "Public read products"
  on public.products for select using (true);

create policy "Authors manage their products"
  on public.products for all
  using (auth.uid() = author_id)
  with check (auth.uid() = author_id);

-- Purchases: users can only see their own purchases
create policy "Users read own purchases"
  on public.purchases for select
  using (auth.uid() = user_id);

-- Only service role can insert purchases (done via webhook)
create policy "Service role inserts purchases"
  on public.purchases for insert
  with check (auth.role() = 'service_role');

-- ─── Increment downloads helper ─────────────────────────────
create or replace function public.increment_downloads(product_id uuid)
returns void language plpgsql security definer as $$
begin
  update public.products set downloads = downloads + 1 where id = product_id;
end;
$$;

-- ─── Storage bucket for asset files ─────────────────────────
-- Run separately in Storage tab or via the Supabase dashboard:
-- 1. Create a bucket named "assets" (private)
-- 2. Files uploaded as: assets/{product_id}/{filename}.zip
